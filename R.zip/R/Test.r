library(fireData)
library(gtools)
library(randomForest)
json_data1<-download(projectURL = "https://train-911f9.firebaseio.com/", fileName = "track")
len<-length(json_data1)

name<-names(json_data1[1])
len1<-length(json_data1[[1]])
temp<-as.data.frame(json_data1[[1]][[len1]])
colnames(temp)<-gsub("X.","",colnames(temp))
colnames(temp)<-gsub(".","",colnames(temp),fixed = T)

colnames(temp)<-paste("mac",colnames(temp),sep = "_")


temp[colnames(temp)]<-sapply(temp[colnames(temp)],as.character)
temp[colnames(temp)]<-sapply(temp[colnames(temp)],as.integer)
previous<-read.csv("data.csv")
previous<-previous[-1]
track<-smartbind(previous[,-1],temp,fill = 0)
parameter<-read.csv("parameternames.csv")
tv<-NULL
for(i in 1:length(parameter))
{
  t<-paste(parameter[[i]])
  tv<-c(tv,t)
}
parameter<-tv
track<-track[,parameter]
tracklen<-nrow(track)
trainmodel<-readRDS("trainmodel.rds")
result<-predict(trainmodel,track[tracklen,])
result<-as.data.frame(result,row.names = NULL)
var<-paste(name,"/Result")
var<-gsub(" ","",var)
upload(result[[1]], projectURL = "https://beakon-d48a8.firebaseio.com/",var)
write.csv(result,"result.csv")


