library(fireData)
library(gtools)
library(mlbench)
library(caret)
library(e1071)
library(randomForest)
json_data<-download(projectURL = "https://train-911f9.firebaseio.com/", fileName = "train")
len<-length(json_data[[1]])
dataframe<-NULL
temp1<-NULL
temp<-NULL
i=1
replen<-nrow(json_data[[1]][[i]]$data)
temp<-as.data.frame(json_data[[1]][[i]]$data)
temp<-cbind(location=rep(json_data[[1]][[i]]$loc,replen),zone=rep(json_data[[1]][[i]]$zone,replen),temp)
dataframe<-temp
for (i in 2:len) {
  
  replen<-nrow(json_data[[1]][[i]]$data)
  temp<-as.data.frame(json_data[[1]][[i]]$data)
  temp<-cbind(location=rep(json_data[[1]][[i]]$loc,replen),zone=rep(json_data[[1]][[i]]$zone,replen),temp)
  #temp1<-smartbind(temp1,temp)
  dataframe<-smartbind(dataframe,temp,fill = 0)
}
colnames(dataframe)<-gsub("'","",colnames(dataframe))
colnames(dataframe)<-paste("mac",colnames(dataframe),sep = "_")
dataframe[is.na(dataframe)]<-0
dataframe[colnames(dataframe)]<-sapply(as.matrix(dataframe[colnames(dataframe)]),as.character)
dataframe[colnames(dataframe[,-1:-2])]<-sapply(as.matrix(dataframe[colnames(dataframe[,-1:-2])]),as.integer)
dataframe$mac_location<-as.factor(dataframe$mac_location)
dataframe$mac_zone<-as.factor(dataframe$mac_zone)
x<-nearZeroVar(dataframe,saveMetrics = T)
x<-rownames(x[x[,"zeroVar"]+x[,"nzv"]>0,]) 
dataframe<-dataframe[ , !(names(dataframe) %in% x)]
# prepare training scheme
control <- trainControl(method="repeatedcv", number=10, repeats=3)
# train the model
model <- train(mac_location~., data=dataframe, method="lvq", preProcess="scale", trControl=control)
# estimate variable importance
importance <- varImp(model, scale=FALSE)
# summarize importance
#print(importance)
# plot importance
#plot(importance)

parameter<-rownames(importance$importance)
write.csv(t(parameter),file = "parameternames.csv",row.names = F)
formula<-as.formula(paste("mac_location~",paste(parameter,collapse = "+")))
write.csv(dataframe[1,],file = "data.csv")

trainmodel<-randomForest(formula,data = dataframe)

saveRDS(trainmodel,"trainmodel.rds")

